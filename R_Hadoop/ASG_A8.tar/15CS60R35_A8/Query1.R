
Sys.setenv (HADOOP_HOME="/opt/cloudera/parcels/CDH/lib/hadoop")
Sys.setenv (HADOOP_CMD="/opt/cloudera/parcels/CDH/lib/hadoop/bin/hadoop")
Sys.setenv (HADOOP_STREAMING= "/opt/cloudera/parcels/CDH-5.1.0-1.cdh5.1.0.p0.53/lib/hadoop-0.20-mapreduce/contrib/streaming/hadoop-streaming-2.3.0-mr1-cdh5.1.0.jar")

library(rmr2)

output_dir = "/user/mtech/15CS60R35/Out1"

query1 = function(input, output = output_dir,NUM_TAGS){
  
  wc.map=
    function(., lines){
      
      key <- vector(mode = "integer")
      value <- vector(mode = "integer")
      for(line in lines){
      song <- unlist(strsplit(line, split = ","))    
      countTag <- length(unlist(strsplit(x = song[2],split = ";")))
      if(countTag > NUM_TAGS){
      key <- c(key,paste(song[4],song[3]))
      value <- c(value,countTag)
      }
    }
       keyval(key,value)
    }

  mapreduce(
    input = input ,
    output = output,
    input.format = "text",
    map = wc.map,
    combine = F
  )
}


query1("/user/mtech/14CS60R41/lastfm_dataset_modified.csv",NUM_TAGS= 10)


results <- from.dfs (output_dir)
#print (results)

results.df <- as.data.frame (results, stringsAsFactors=F)
colnames(results.df) <- c ('track Id', 'Tag count')
#head (results.df)

