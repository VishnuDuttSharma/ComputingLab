
Sys.setenv (HADOOP_HOME="/opt/cloudera/parcels/CDH/lib/hadoop")
Sys.setenv (HADOOP_CMD="/opt/cloudera/parcels/CDH/lib/hadoop/bin/hadoop")
Sys.setenv (HADOOP_STREAMING= "/opt/cloudera/parcels/CDH-5.1.0-1.cdh5.1.0.p0.53/lib/hadoop-0.20-mapreduce/contrib/streaming/hadoop-streaming-2.3.0-mr1-cdh5.1.0.jar")

library(rmr2)

output_dir = "/user/mtech/15CS60R35/Out3"

query3 = function(input, output = output_dir,NUM_TAGS,SONG_TAG){
  
  wc.map=
    function(., lines){
      
      key <- vector(mode = "integer")
      value <- vector(mode = "integer")
      for(line in lines){
        song <- unlist(strsplit(line, split = ","))  
        artist <- unlist(strsplit(x = song[1],split = ";"))
        for(a in artist){
          if(length(unlist(strsplit(x = song[2],split = ";"))) > NUM_TAGS){
          key <- c(key,a)
          
          value <- c(value,paste(song[3],song[4]))
          }
        }
      }
      keyval(key,value)
    }
  wc.reduce =
    function(key, value ){
      
      v <- vector(mode = "integer")
      i <- 1
      for(s in value){
        v <- c(v,s)
        i = i+1
      }
      if(i >= NUM_SONG )
        keyval(key,paste(v,collapse = " "))
    }  
  mapreduce(
    input = input ,
    output = output,
    input.format = "text",
    map = wc.map,
    reduce = wc.reduce,
    combine = F
  )
}


query3("/user/mtech/14CS60R41/lastfm_dataset_modified.csv",NUM_TAGS= 10,NUM_SONG=2)


results3 <- from.dfs (output_dir)
#print (results)

results.df3 <- as.data.frame (results3, stringsAsFactors=F)
colnames(results.df3) <- c ('Artist,Song Name,Song ID', 'Song Sung count')
#head (results.df)

