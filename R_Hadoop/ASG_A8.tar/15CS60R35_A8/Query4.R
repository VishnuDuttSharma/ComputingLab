
Sys.setenv (HADOOP_HOME="/opt/cloudera/parcels/CDH/lib/hadoop")
Sys.setenv (HADOOP_CMD="/opt/cloudera/parcels/CDH/lib/hadoop/bin/hadoop")
Sys.setenv (HADOOP_STREAMING= "/opt/cloudera/parcels/CDH-5.1.0-1.cdh5.1.0.p0.53/lib/hadoop-0.20-mapreduce/contrib/streaming/hadoop-streaming-2.3.0-mr1-cdh5.1.0.jar")

library(rmr2)

output_dir = "/user/mtech/15CS60R35/Out4"

query4 = function(input, output = output_dir){
  
  wc.map=
    function(., lines){
      
      key <- vector(mode = "integer")
      value <- vector(mode = "integer")
      for(line in lines){
        song <- unlist(strsplit(line, split = ","))  
        artist <- unlist(strsplit(x = song[1],split = ";"))
        for(a in artist){
          key <- c(key,a)
          value <- c(value,paste(song[3],song[4]))
        }
      }
      keyval(key,value)
    }
  wc.reduce =
    function(key, value ){
      

        keyval(key,paste(value,collapse = "&"))
    }  
  mapreduce(
    input = input ,
    output = output,
    input.format = "text",
    map = wc.map,
    reduce = wc.reduce,
    combine = F
  )
}


query4("/user/mtech/14CS60R41/lastfm_dataset_modified.csv")


results4 <- from.dfs (output_dir)
#print (results)

results.df4 <- as.data.frame (results4, stringsAsFactors=F)


#creating index

#first create 26 lists to contain authors whose names start with particular alphabat

abcd <- "aA"
for(i in 2:26)
  abcd <-  c(abcd,paste(c(letters[seq( from = i, to = i )],LETTERS[seq( from = i, to = i )]),collapse=""))

index <- list()
for(i in 1:26){
  reg <- paste(c("^[",abcd[i],"].*"),collapse="")
  count <- grep(reg,results.df4[,1])
  temp <- count
  names(temp) <- results.df4[count,1]
  temp<-list(temp)
  index <- append(index,temp)
}

ind <- c(rep(1:26))
names(ind) <- c(letters[seq( from = 1, to = 26 )])
searchSong <- function(authorName){
  indexOflist <- ind[tolower(substr(authorName,1,1))]
  if(authorName %in% names(index[[indexOflist]])){
    songs <- unlist(strsplit(results.df4[index[[indexOflist]][authorName],2],split="&"))
    return (songs)
  }else{
    return ("No results found corresponding to the input artist")
  }
}



colnames(results.df) <- c ('Artist,Song Name,Song ID', 'Song Sung count')
#head (results.df)

