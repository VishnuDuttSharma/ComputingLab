#include <stdio.h>
#include <stdlib.h>

#define NUM_GUESTS 30

/**
* SEM_MAACH_ENABLE string used as name in named semaphore maachEnable
* SEM_DAL_ENABLE string used as name in named semaphore dalEnable
* SEM_BHAAT_ENABLE string used as name in named semaphore for bhaatEnable
*/
#define SEM_MAACH_ENABLE "/maachEnable"
#define SEM_DAL_ENABLE "/dalEnable"
#define SEM_BHAAT_ENABLE "/bhaatEnable"

/**
*	@brief \var maachEnable Pointer to semaphore for enabling 'Maach' in Service Room process
*	@brief \var dalEnable Pointer to semaphore for enabling 'Dal' in Service Room process
*	@brief \var bhaatEnable Pointer to semaphore for enabling 'Bhaat' in Service Room process
*/
sem_t *maachEnable, *dalEnable , *bhaatEnable;

struct SRO_table{
  char *name;
  float entryTime;
  int roomId;
};


void make_srot()
{
    struct SRO_table *mySRO = ( struct SRO_table *)malloc( NUM_GUESTS * sizeof(struct SRO_table));


}

void serveGuest(int item)
{
  while(1){
    switch( item ){
      case 0:
        sem_wait( maachEnable);
        break;
      case 1:
        sem_wait( dalEnable);
        break;
      case 2:
        sem_wait( bhaatEnable);
        break;

      sleep(1);

    }
  }
}

void initService()
{
  maachEnable = sem_open( SEM_MAACH_ENABLE, 0);
  dalEnable = sem_open( SEM_DAL_ENABLE, 0);
  bhaatEnable = sem_open( SEM_BHAAT_ENABLE, 0);
}

int main(int argc, char *argv[])
{
  pid_t pid;
  int i;

  for(i = 0; i < 3; i++){
    if ((pid = fork()) == 0){

    }
  }

  sem_close( maachEnable);
  sem_close( dalEnable);
  sem_close( bhaatEnable);

  sem_unlink(SEM_MAACH_ENABLE);
  sem_unlink(SEM_DAL_ENABLE);
  sem_unlink(SEM_BHAAT_ENABLE);

}
